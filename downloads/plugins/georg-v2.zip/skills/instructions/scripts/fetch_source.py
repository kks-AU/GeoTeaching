"""Fetch a GeoTeaching HTML page as readable text; no external dependencies."""
import argparse, datetime, hashlib, json, pathlib, sys
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from urllib.parse import urljoin, urlparse

BASE = 'https://kks-au.github.io/GeoTeaching/'
class Text(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.skip=0; self.links=[]
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.skip += 1
        if tag in ('p','div','section','h1','h2','h3','li','br','tr'): self.parts.append('\n')
        if tag == 'a':
            self.links.extend(v for k,v in attrs if k=='href')
    def handle_endtag(self, tag):
        if tag in ('script','style'): self.skip -= 1
        if tag in ('p','div','section','h1','h2','h3','li','tr'): self.parts.append('\n')
    def handle_data(self, data):
        if not self.skip: self.parts.append(data)

def fetch(page):
    url=urljoin(BASE,page)
    parsed=urlparse(url)
    if parsed.scheme!='https' or parsed.netloc!='kks-au.github.io' or not parsed.path.startswith('/GeoTeaching/'):
        raise ValueError('Only GeoTeaching HTTPS pages are allowed')
    with urlopen(Request(url,headers={'User-Agent':'GEORG-V2-source-reader/0.20.2'}),timeout=30) as response:
        if not response.url.startswith(BASE): raise ValueError('Unexpected redirect')
        raw=response.read(5_000_001)
        if len(raw)>5_000_000: raise ValueError('Page too large')
        html=raw.decode('utf-8')
    parser=Text(); parser.feed(html)
    body='\n'.join(line.strip() for line in ''.join(parser.parts).splitlines() if line.strip())
    return {'url':url,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256_html':hashlib.sha256(raw).hexdigest(),'text':body,'html':html,'links':[urljoin(url,x) for x in parser.links]}

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('page',nargs='?',default='index.html'); ap.add_argument('--output'); args=ap.parse_args()
    try:
        result=fetch(args.page)
        output=json.dumps(result,ensure_ascii=False,indent=2)
        if args.output: pathlib.Path(args.output).write_text(output,encoding='utf-8')
        else: print(output)
    except Exception as exc:
        print('Source retrieval failed: '+str(exc),file=sys.stderr); sys.exit(1)
