# GeoTeaching-kilder

Fagligt grundlag: **Geoteknik, 3. udgave**. GeoTeaching er undervisningsmateriale med henvisninger til bogen, ikke en fuld udgave af bogen.

## Hent en konkret side

Kør fra en tilgængelig PowerShell med scriptets fulde installerede sti:

```powershell
& '<pluginrod>/skills/instructions/scripts/Get-GeoTeaching.ps1' -Page 'eksempler/paele.html'
```

Resultatet er JSON med `url`, `fetched_at_utc` og `content` (rå HTML). Læs relevant brødtekst, ligninger og forudsætninger i `content`. HTML indeholder MathML; behold symboler og enheder ved læsning. Scriptet henter kun HTML/JavaScript fra GeoTeaching, afviser andre værter og omdirigeringer og fejler synligt ved netværksfejl. Det kræver PowerShell og netadgang. I værter uden lokal udførelse bruges webhentning eller de medfølgende kildesider.

Hvis en beregning afhænger af JavaScript, som HTML-siden ikke dokumenterer, hent den konkrete scriptsti fra sidens script-tags og læs den relevante funktion. De lokale snapshots indeholder HTML, ikke en køreklar kopi af simulatorerne. Gæt ikke simulatorens beregningsmetode.

## Lokale kildesider

`sources/manifest.json` angiver oprindelig URL, hentetidspunkt, attribution, licens og SHA-256 for hver uændret HTML-side. Brug snapshotdatoen ved henvisning, hvis liveadgang ikke lykkes. Snapshots gør kildeindhold læsbart uden webværktøj; tilstedeværelse eller download er aldrig bevis for faglig kontrol.

| Quizemne | Start med denne fil under sources/ |
| --- | --- |
| 1 Klassifikation af jord | emner/jordegenskaber.html (undersøg dækningen; ingen garanti for fuld klassifikationslære) |
| 2 Spændinger i jord | eksempler/spaendinger.html |
| 3 Jords deformationer | eksempler/deformation.html; eksempler/konsolideringsforsog.html |
| 4 Konsolideringens tidsforløb | eksempler/konsolidering.html |
| 5 Jords styrke | eksempler/styrke.html |
| 6 Brud i jordmasser | eksempler/rankine.html (kun det dækkede jordtryksemne) |
| 7 Fundamenters bæreevne | eksempler/baereevne.html |
| 8 Fundamenters sætninger | eksempler/saetninger.html |
| 9 Enkeltpæles bæreevne | eksempler/paele.html |

Menuens numre er bevaret som quizvalg og må ikke citeres som bogkapitler. Læs boghenvisningen på den relevante side. Sidetal må kun gengives som henvisning oplyst af GeoTeaching og må ikke udvides eller beregnes. Et eksempel: hvis siden henviser til et boginterval, betyder det ikke, at pluginet har læst bogintervallet. Bekræft kun kontrol af de konkrete forhold, som den faktisk læste kildetekst understøtter.

Attribution: GeoTeaching, Kenny K. Sørensen, Aarhus Universitet, https://kks-au.github.io/GeoTeaching/. Originalt undervisningsmateriale er CC BY 4.0; kildekode MIT. Ingen fotos, logoer eller bogscanninger er kopieret som kildebilag.
