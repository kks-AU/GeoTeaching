param([string]$Page = 'index.html')
$ErrorActionPreference = 'Stop'
$base = [uri]'https://kks-au.github.io/GeoTeaching/'
$uri = [uri]::new($base, $Page)
if ($uri.Scheme -ne 'https' -or $uri.Host -ne $base.Host -or -not $uri.AbsolutePath.StartsWith($base.AbsolutePath) -or $uri.AbsolutePath -notmatch '\.(html|js)$') { throw 'Kun HTML og JavaScript under GeoTeaching er tilladt.' }
$response = Invoke-WebRequest -Uri $uri.AbsoluteUri -MaximumRedirection 0 -TimeoutSec 30
[ordered]@{url=$uri.AbsoluteUri; fetched_at_utc=[DateTime]::UtcNow.ToString('o'); content=$response.Content} | ConvertTo-Json -Depth 5
